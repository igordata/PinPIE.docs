<h1>Hello</h1>
<p>Hi!</p>
<p>The answer is [[$rand]].</p>
<p>Now visit <a href="/about">another page</a>.</p>
[[lorem/ipsum]]