<?php
echo rand(1, 999);