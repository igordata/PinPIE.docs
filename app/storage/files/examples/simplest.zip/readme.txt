This is an example from PinPIE documentation.

http://pinpie.ru/en/examples/simplest