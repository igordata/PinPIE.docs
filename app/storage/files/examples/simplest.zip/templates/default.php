<html>
<head></head>
<body>[[*content]]</body>
</html>