<!DOCTYPE html>
<html lang='ru'>
  <head>
    [[!$head]]
  </head>
  <body>
    [[*content]]
  </body>
  [[!$bottom]]
</html>